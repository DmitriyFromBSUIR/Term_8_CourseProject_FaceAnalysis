'''
Created on 12-02-2013

@author: Wiktor
'''

#import RemoveNonMp3Files
from numpy import *    #Generalnie nie wiadomo o co tu chodzi

A=array([[1,2,100],[100,100,6]])
B=(A==100)
print nonzero(B)
#(x,y)= nonzero(B)
#print "x=", x
#print "y=", y
