'''
Created on 18-02-2013

@author: Wiktor
'''
