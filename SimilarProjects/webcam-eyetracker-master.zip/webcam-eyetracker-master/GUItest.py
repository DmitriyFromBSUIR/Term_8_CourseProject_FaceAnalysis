# CamTracker GUI test

from camtracker import Setup

# initialize setup
setup = Setup()

# run GUI
tracker = setup.start()